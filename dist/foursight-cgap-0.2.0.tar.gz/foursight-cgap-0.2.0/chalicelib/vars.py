FOURSIGHT_PREFIX = 'foursight-cgap'
DEV_ENV = 'cgapdev'
FAVICON = 'https://cgap.hms.harvard.edu/static/img/favicon-fs.ico'
HOST = 'https://search-foursight-fourfront-ylxn33a5qytswm63z52uytgkm4.us-east-1.es.amazonaws.com'
